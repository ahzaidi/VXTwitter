https://chromewebstore.google.com/detail/vxtwitter-url-modifier/fjphdcobpcafboggpjdimkcbgcbghlfh?hl=en-GB

Modifies Twitter URLs to start with 'vx' and copies the modified URL.

To use:

CRTL + C on any Twitter post and paste to destination of choice.

what is VX Twitter?
https://github.com/dylanpdx/BetterTwitFix
